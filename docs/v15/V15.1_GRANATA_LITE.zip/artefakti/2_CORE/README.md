# ⚙️ ARTEFAKTS #2 · CORE — KANONĪSKAIS PAMATS

> **Šī ir sistēmas neaiztiekamā KODOLA. Q1-Q40, V8 mezgli, V13 disciplīna.**
>
> *V14.1 LV_MASTER_SCRIPT.md ir BYTE-FOR-BYTE neaizskarta no V14.1 versijas. Visas V15/V15.1 atjauninājumi pievieno ārējus slāņus, neskar šo failu.*

---

## Kas ir iekšā

| Fails | Lpp | Avots |
|---|---|---|
| `LV_MASTER_SCRIPT_V14_1.md` | 2128 līnijas | V14.1 kanons (sacrosanct) |
| `V14.1_PREMIUM_BOOK_REFERENCE.pdf` | 98 | V14.1 reference (typesetting template) |
| `V15_OPERATOR_CORK.pdf` | 1 | Kabatas slānis (drukāt blakus telefonam) |
| `V15_KODONS.pdf` | 1 | 9 likumu esence (turi galvā kā kodu) |
| `V15_QUICK_REFERENCE.pdf` | 2 | Ātrās atsauces (6 iebildumi 60 sek + 3 close + 5 klusumi) |

---

## Kodola sastāv

### V13 6-slāņu disciplīna (sacrosanct)

```
1. CORE          — Q1-Q40 skripts (ekspozētais)
2. CORK          — kabatas slānis (operatorā lasāms)
3. ARSENAL       — situatīvi paņēmieni (kad reāli vajag)
4. TRAINING      — operatori mācās (kursi, drili)
5. SPECIAL CASE  — anomālijas (CEO, multiple decision-makers)
6. CARRIER       — vizuālās metaforas (ne stāsti, ne fakti — bildes)
```

**Kategoriski aizliegts:** sajaukt CORE ar ARSENAL zvanā · lasi CORK pa lapām · lieto SPECIAL bez anomālijas signāliem · lieto vairāk kā 1 vizuālu metaforu vienā zvanā.

### Q1-Q40 + 5 vārtu mezgli

```
Q1 → Q2 → [Q3 VĀRTS#1] → Q4 → Q5 → Q6 → Q7 → Q8 → Q9 → Q10 →
[Q11 VĀRTS#2] → Q12 → ... → Q21 → [Q21.5 VĀRTS#3 ⭐] → Q22 → ... →
[Q26 VĀRTS#4] → ... → [Q32 VĀRTS#5] → ... → Q40
```

**5 vārti:**
1. **Q3 Soft Frame** — diagnostikas pieeja
2. **Q11 GAP €N** — konkrēts cipars
3. **Q21.5 Hope Break ⭐** — LOAD-BEARING
4. **Q26 3 Pīlāri** — strukturāls piedāvājums
5. **Q32 Cena + Klusums** — 8-15 sek

**Bez visiem 5 vārtiem nav slēgšanas.** Var piekrist vispār, bet zvana laikā nepāries uz reālu lēmumu.

### V8 14 mezgli × 8 slāņi katrs

Klienta domāšanas iekšējā arhitektūra zvana laikā. Katrs mezgls ir 8-slāņu konstrukts:
- Mērķis · Frāzes · Vārti · Iebildumi · Klusumi · NLP slānis · V13 māja · Audita pēdas

Sk. Premium Book Daļa XII vai Blueprint #11.

### MICE 4 motori

- **M**oney — peļņa, ROI
- **I**deology — vīzija, mantojums
- **C**ompromise — drošība, partneris
- **E**go — prestižs, atriebība

Q4-Q7 atklāj dominanto → Q22+Q26 valodu pielāgo.

---

## Operatora dienas rituāls

**Rīts (5 min):** Klausies V15_KODONS_audio.mp3 → drukā V15_OPERATOR_CORK.pdf
**Pirms zvana (90 sek):** V15_PRECALL_RITUAL_audio.mp3
**Zvanā:** Tava cork blakus, NEAITIEC pie skripta
**Pēc zvana (10 min):** Audit ar Daļa VIII (Lēmumu Algoritms) — kurā solī iesprūdis?

---

## Integritātes apstiprinājums

```
SHA256 V14.1 LV_MASTER_SCRIPT (sacrosanct):
  - Atveriet failu un pārbaudiet pret git history.
  - Ja byte-for-byte mainīts no V14.1 → tas IR kļūda, un jāatgriežas pie original.
  
V15/V15.1 PIEVIENO ārējus slāņus, NESKARS šo failu.
```
