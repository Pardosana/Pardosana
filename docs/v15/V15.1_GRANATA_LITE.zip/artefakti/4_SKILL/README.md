# 🎓 ARTEFAKTS #4 · SKILL — OPERATORA APMĀCĪBAS KIT

> **30 dienu apmācības programma** — no nulles uz V15 Eksperta līmeni.

---

## Kas ir iekšā

| Fails | Mērķis |
|---|---|
| `V15_OPERATOR_CORK.pdf` (+ MP3) | Kabatas slānis · drukāt blakus telefonam |
| `V15_KODONS.pdf` (+ MP3) | 9 likumu esence · galvā kā kodu |
| `V15_QUICK_REFERENCE.pdf` (+ MP3) | 6 iebildumi · 3 close · 5 klusumi |
| `V15_PRECALL_RITUAL_audio.mp3` | 90 sek pre-call protokols |
| `V15_CUSTOMER_ARCHETYPES.pdf` | 6 tipu playbook |
| `V15_WHITEBOARD_TEMPLATES_A3.pdf` | 4 A3 šabloni klientiem |
| `roleplay.html` | Interaktīvs simulators (atver browserī) |
| `knowledge_graph.html` | Q1-Q40 + V8 mezglu pārlūks |

---

## 30-DIENU APMĀCĪBAS PROGRAMMA

### 1. nedēļa · Pamati (Foundation)

| Diena | Aktivitāte | Laiks |
|---|---|---|
| 1 | Klausies KODONS audio + lasi PDF (5 reizes) | 30 min |
| 2 | Klausies QUICK_REFERENCE audio + drukā PDF | 45 min |
| 3 | Pirmoreiz lasi V15 Premium Book Daļa I-II (Q1-Q10) | 90 min |
| 4 | Lasi V15 Premium Book Daļa II (Q11-Q21) | 90 min |
| 5 | **KRITISKĀ DIENA:** Lasi Daļa IX Hope Fog Shatterer (Q21.5) 3 reizes | 120 min |
| 6 | Lasi V15 Premium Book Daļa II (Q22-Q40) | 90 min |
| 7 | Atkārtošana — visa Q1-Q40 ķēde + 5 vārti | 60 min |

### 2. nedēļa · Vizuālā integrācija

| Diena | Aktivitāte | Laiks |
|---|---|---|
| 8 | Pārskata Blueprint #1-#3 (Sistēma + V13 + Q-flow) | 30 min |
| 9 | Pārskata Blueprint #4 Hope Fog + #6 COI | 30 min |
| 10 | Pārskata Blueprint #5 MICE + #7 Algoritms | 30 min |
| 11 | Pārskata Blueprint #8-#11 | 60 min |
| 12 | **Drukā A3 šablonus** (visus 4) un mēģini ar partneri | 120 min |
| 13 | Atkārto Hope Fog A3 šablonu — pati ar sevi | 30 min |
| 14 | Lasi Daļa VIII Lēmumu Algoritms 2 reizes | 90 min |

### 3. nedēļa · Roleplay drilles

| Diena | Aktivitāte | Laiks |
|---|---|---|
| 15 | Atver `roleplay.html` → Skeptiķis (3 zvani) | 45 min |
| 16 | Roleplay → Vizionārs (3 zvani) | 45 min |
| 17 | Roleplay → Pragmatiķis (3 zvani) | 45 min |
| 18 | Roleplay → Lepnais (3 zvani) | 45 min |
| 19 | Roleplay → Analītiķis (3 zvani) | 45 min |
| 20 | Roleplay → Pirmsreizējais (3 zvani) | 45 min |
| 21 | Atkārto vajadzīgākos arhetipus (kuri zem 70/100) | 60 min |

### 4. nedēļa · Live testēšana

| Diena | Aktivitāte | Laiks |
|---|---|---|
| 22 | Pirmais live zvans ar V15 sistēmu (audio + cork) | 1 zvans |
| 23 | Pēc-zvana audit pēc Lēmumu Algoritma | 30 min |
| 24 | Lasi Daļa VI Validētais Arsenāls (11 mezgli) | 90 min |
| 25 | Pārskata Daļa XI Operatora Rituāls + 90 sek protokols | 30 min |
| 26 | 2-3 live zvani + audit | live |
| 27 | Lasi Daļa XII V8 Molekulāra mape | 60 min |
| 28 | 2-3 live zvani + audit | live |
| 29 | Pārskata pricing tieru un arhetipu mapping | 60 min |
| 30 | **Pārbaudījums:** 5 live zvani vienā dienā ar pilnu V15 disciplīnu | live |

---

## Pirms katra zvana (rituāls)

1. **0-15s** — Power Pose (rokas augšā V vai uz gurniem, smaids)
2. **15-35s** — Elpa 4-4-6 (4 sek ievelc, 4 sek tur, 6 sek izlaiz × 5)
3. **35-55s** — Pipeline review (CRM atvērts, 25-30 atvērti darījumi)
4. **55-75s** — MICE kalibrācija (kāds tips šis klients?)
5. **75-90s** — Mantras (3×):
   - *"Es nestrādāju ar visiem."*
   - *"Es nepārdošu, es diagnozēju."*
   - *"Cerība nav sistēma."*

**Tas ir audio fails `V15_PRECALL_RITUAL_audio.mp3` — atskaņo headphones-os pirms zvana.**

---

## Pēc katra zvana (10 min audit)

1. Kurā soli (Q-numurā) klients iesprūdis?
2. Vai izgāju visus 5 vārtus?
3. Vai Q21.5 Hope Break **REĀLI** notika? Vai klients pats atzina, ka cer?
4. Vai pēc Q32 cenas izpildīju 8-15 sek klusumu?
5. Kāds bija MICE motors? Vai Q22+Q26 tika pielāgoti tam?

Atbildot uz šiem 5, redzi savu vājāko vietu → atgriezies pie konkrēta Daļa Premium Book.

---

## Eksperta līmenis (sasniegts pēc 30 dienām)

✓ Q1-Q40 zini bez kabines slāņa (cork ir tikai backup)
✓ Q21.5 Hope Break izpildi katrā zvanā automātiski
✓ Klusais slēgums 8-15 sek (NEPIRMAIS, kas pārtrauc)
✓ MICE motoru atpazīsti Q4-Q7 ietvaros
✓ A3 šabloni ir tava noklusējuma whiteboard valoda
✓ Roleplay drillu vidēji 80+/100 katram arhetipam

**Ieteikums:** Pēc 30 dienām atver atkal `roleplay.html` reizi mēnesī, lai uzturētu formu.
