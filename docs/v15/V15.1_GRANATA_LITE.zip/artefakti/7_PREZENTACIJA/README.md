# 🎬 ARTEFAKTS #7 · PREZENTĀCIJA

> **V15.1 prezentācijas master deck — 21 slaidi A4 landscape, V14.1 Premium Book stilā.**

---

## Kas ir iekšā

| Fails | Apjoms | Mērķis |
|---|---|---|
| `V15_1_PREZENTACIJA.pdf` | 21 slaidi · 120 KB | PDF — drukāt vai prezentēt no laptopa |
| `V15_1_PREZENTACIJA.html` | 25 KB | HTML — atver browserī interaktīvi |

---

## 21 slaidu struktūra

| # | Saturs | Tips |
|---|---|---|
| 1 | Cover · V15.1 | NAVY/GOLD |
| 2 | Pamats · V15 = V14.1 + 3 ārējie slāņi | Standard |
| 3 | V13 disciplīna · 6 slāņi nedrīkst sajaukt | Tabula |
| 4 | Q1-Q40 plūsma · 8 fāzes · 5 vārti | Diagramma |
| 5 | Q21.5 Hope Break ⭐ load-bearing | Highlight |
| 6 | Daļa VI · 11 jaunie mezgli | Tabula |
| 7 | Daļa VII · IG validācija statistika | Tabula |
| 8 | Daļa VIII · 7-soļu lēmumu algoritms | Diagramma |
| 9 | Daļa IX · Hope Fog Shatterer 3-step | Highlight |
| 10 | Daļa X · Blueprint atlanta priekšskats | Standard |
| 11 | MICE motors · 4 kvadrants | Diagramma |
| 12 | CARE ietvars | Tabula |
| 13 | Klusais slēgums · 8-15 sek | Highlight |
| 14 | Operatora rituāls · 90 sek pre-call | Diagramma |
| **15** | ⭐ **V15.1** · 12 LV blueprint shēmas | Tabula |
| **16** | ⭐ **V15.1** · 4 A3 šabloni klientiem | Tabula |
| **17** | ⭐ **V15.1** · 6 klientu arhetipi | Tabula |
| **18** | ⭐ **V15.1** · 4 cenu līmeņi | Tabula |
| **19** | ⭐ **V15.1** · Knowledge Graph + Roleplay | Diagramma |
| 20 | Changelog V14.1 → V15 → V15.1 | Tabula |
| 21 | KODONS · "Cerība nav sistēma" | Cover |

---

## Kā lietot

### Vienatnē (mācībām)
Atver `V15_1_PREZENTACIJA.html` browserī. Skritē cauri visiem slaidiem (~5 min). Izlasi katru kontekstu.

### Komandas apmācībai (60 min)
1. Slaidi 1-5 (15 min) — pamati: V15 esence + Q-flow + Hope Break
2. Slaidi 6-14 (25 min) — saturs: 11 mezgli, validācija, algoritms, rituāls
3. **Slaidi 15-19 (15 min) — V15.1 jaunumi: blueprintus, A3, arhetipus, cenas, web rīkus**
4. Slaidi 20-21 (5 min) — changelog + KODONS

### Klientiem (sales pitch)
Drukā PDF (A4 landscape) → laminēt → izrādīt klientam pirms zvana. Rāda **profesionalitāti** un sistēmas dziļumu.

### Investoriem (fundraising)
Sūti PDF kā pielikumu emailam. Pārliecina, ka V15.1 ir **strukturēta sistēma**, ne ad-hoc paņēmieni.

---

## Tehniskais

- **Formāts:** A4 landscape (297 × 210 mm)
- **Krāsas:** NAVY (#0d3b66) · GOLD (#d97706) · GOLD_LIGHT (#ffd24a) · INK (#16243a) · PAPER (#fffaf0)
- **Fonts:** Georgia / DejaVu Serif
- **Marges:** 18-22mm
- **Render:** WeasyPrint (HTML → PDF)

Ja gribi pielāgot — atver `V15_1_PREZENTACIJA.html`, redaktor HTML, regenerē PDF ar build script: `python3 /home/ubuntu/v15-build/build_v15_presentation.py`.
