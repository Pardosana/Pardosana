# 🏆 GALĪGĀ PĀRDOŠANAS ROKASGRĀMATA
## Autopilot Pārdošanas Sistēma — Pilnīgs Ceļvedis

> Šī rokasgrāmata ir sintezēta no 100+ pārdošanas video (Instagram, Facebook, YouTube), apvienojot Jordan Belfort Straight Line metodi, Ryan Serhant stratēģijas, Simon Sinek "Sāc ar Kāpēc" filozofiju un labākās mūsdienu pārdošanas tehnikas.

### SATURS

1. AUTORITĀTE UN POZICIONĒŠANA
2. IEBILDUMU APSTRĀDE — MEISTARU SKRIPTI
3. SLĒGŠANAS TEHNIKAS
4. STEIDZAMĪBA UN BEZDARBĪBAS IZMAKSAS
5. PSIHOLOĢIJA — LOJALITĀTE, SINEK, SERHANT
6. DOMINO SKRIPTS — PILNĀ SISTĒMA
7. 6 IEBILDUMI 60 SEKUNDĒS
8. IKDIENAS PĀRDOŠANAS RITUĀLI
- Pielikums A: Ātrās References Kartīte
- Pielikums B: Skriptu Veidnes Reālām Situācijām
- Pielikums C: Psiholoģisko Trigeru Enciklopēdija
- Pielikums D: Noslēguma Atgādnes — 10 Zelta Likumi

---

## 1. AUTORITĀTE UN POZICIONĒŠANA
### Kā Nebūt Izmisušam — Pārpilnības Domāšana

### 1.1 Pamatprincips: Cilvēks, Kuram Darījums Ir Vismazāk Vajadzīgs, To Visvairāk Iegūst

Kad pārdod no izmisuma, pircēji jūt tā saukto "komisijas dvašu" — enerģijas maiņu, kas fokusē uz tavām vajadzībām, nevis klienta. Tas iedarbina zemapziņas pretestību, nevis uzticēšanos.

**Galvenā atziņa:** *"Es vēlos tavu biznesu, bet man tas nav VAJADZĪGS."*

### 1.2 Autoritātes Pozicionēšanas Tehnikas

#### 🔑 Tehnika #1: Vienlīdzīga Biznesa Pozīcija
Komunicē, ka esi selektīvs attiecībā uz to, ar ko strādā. Ne visi ir piemēroti — tostarp novērtē, vai VIŅI ir piemēroti TEV.

> *"Pirms mēs turpinām, gribu būt godīgs — es nestrādāju ar visiem. Man ir svarīgi saprast, vai mēs esam savstarpēji piemēroti. Vai varat pastāstīt vairāk par savu situāciju, lai es varu novērtēt, vai tiešām spēju jums palīdzēt?"*

#### 🔑 Tehnika #2: Padomdevējs, Nevis Pārdevējs
Pārvērt sevi no pārdevēja par padomdevēju. Padomdevēji rada uzticēšanos, uzticēšanās rada ieteikumus.

> *"Es necentīšos jums neko pārdot. Mana loma ir palīdzēt jums izprast situāciju un pieņemt labāko lēmumu — pat ja tas nozīmē, ka šobrīd mēs nesadarbojamies. Vai tas ir godīgi?"*

#### 🔑 Tehnika #3: Finansiālā Disciplīna = Pārdošanas Priekšrocība
Zemas personīgās izmaksas = augstas autoritāte. Tu burtiski nevari tikt iespaidots slēgt sliktus darījumus.

> *"Kad tev nav parādu un tavas ikdienas izmaksas ir zemas, tu pārdod no brīvības pozīcijas. Klienti to jūt — viņi uzticas cilvēkam, kurš runā no pārliecības, nevis no baiļu."*

#### 🔑 Tehnika #4: Pipeline Dziļums (25-30 iespējas)
Praktiskākais veids, kā pāriet uz pārpilnības domāšanu — piepildi savu pipeline ar 25-30 reālām iespējām dažādos posmos.

> *"Man ir 27 atvērti darījumi. Šis ir viens no tiem. Es dodu vislabāko, bet mans panākums nav atkarīgs no šī viena rezultāta."*

### 1.3 Ryan Serhant 2-C Formula
Katrā mijiedarbībā sniedz: (1) patiesu komplimentu + (2) atrod kaut ko kopīgu.

**Pirmā tikšanās:**

> *"Jūsu pieeja [konkrētā joma] ir ievērojama — reti satiku cilvēkus, kas to dara tik apzināti. Starp citu, es arī [kopīgais elements]. Būtu lieliski atrast laiku un izpētīt, kā mēs varētu viens otram palīdzēt."*

**Sekošana pēc 10 minūtēm (Serhant metode):**

> *"Prieks bija tikties pirms 7,5 minūtēm! Jūsu [kompliments] tiešām palika prātā. Darīsim kaut ko lielisku kopā — kad jums ir laiks šonedēļ?"*

### 1.4 Valodas Maiņa: No Izmisuma uz Autoritāti

| ❌ Izmisīgā Valoda | ✅ Autoritātes Valoda |
|---|---|
| "Kā es varu jums palīdzēt?" | "Vai esat šeit bijuši iepriekš?" |
| "Vai jūs interesē?" | "Balstoties uz jūsu situāciju, šeit ir tas, ko es iesaku." |
| "Es nosūtīšu jums informāciju" | "Es sagatavošu analīzi, kas pielāgota jūsu situācijai" |
| "Lūdzu, atzvaniet man" | "Es sazināšos ar jums ceturtdien plkst. 14:00" |
| "Mēs varam piedāvāt atlaidi" | "Mūsu vērtība ir [X], un klienti parasti redz atdevi Y mēnešu laikā" |

---

## 2. IEBILDUMU APSTRĀDE — MEISTARU SKRIPTI

### 2.0 Universālā Iebildumu Apstrādes Formula (VAI)

**V — Validē** (Atzīsti) → **A — Atdalī** (Izolē) → **I — Interpretē no jauna** (Pārformulē)

Šo formulu izmanto KATRAM iebildumam kā pamatu, pirms piemēro specifisko skriptu.

### 2.1 IEBILDUMS: "TAS IR PAR DĀRGU" / "CENA IR PĀRĀK AUGSTA"

#### Skripts A — Trīs "Jā" Tehnika

> Tu: *"Vai jūs vēlaties palielināt savu komandas produktivitāti?"*
> Klients: *"Jā."*
> Tu: *"Vai kļūdu samazināšana ir svarīga jūsu biznesam?"*
> Klients: *"Jā."*
> Tu: *"Un vai jūs gribētu redzēt investīcijas atdevi 3-4 mēnešu laikā?"*
> Klients: *"Jā."*
> Tu: *"Tieši tāpēc mūsu risinājums ir [X] — jo tas nodrošina tieši to, ko tikko nosaucāt."*

#### Skripts B — Vērtības Sendvičs (Priekšrocības-Cena-Priekšrocības)

> *"Es saprotu, ka budžets ir svarīgs. Padomājiet par šo — pirms cenas mēs runājām par to, ka jūsu komanda zaudē 15 stundas nedēļā manuālajā darbā. Tas ir €X mēnesī tikai darba izmaksās. Mūsu risinājums ir €Y — kas ir mazāk nekā mēneša zaudējumi. Pēc 60 dienām tas pats sevi atpelnīs."*

#### Skripts C — Bezdarbības Izmaksu (COI) Skripts

> *"Cik jums izmaksā KATRU MĒNESI, kamēr šī problēma paliek neatrisināta? Aprēķināsim kopā… [pauze]. Jūs man pateicāt, ka zaudējat €X mēnesī. Mūsu cena ir €Y, kas ir lielāka tikai uz vienu mēnesi — bet pēc tam tas kļūst par tīru peļņu."*

### 2.2 IEBILDUMS: "MAN JĀRUNĀ AR PARTNERI / KOMANDU"

#### Skripts A — Pārliecības Pārbaude

> *"Pilnīgi saprotu. Pirms tas notiek — gribu jums palīdzēt sagatavoties. Vai PATS esat par 100% pārliecināts, ka šis ir pareizais risinājums? [Pauze.] Ja jā — kādus jautājumus partneris uzdos? Sagatavosim atbildes kopā."*

#### Skripts B — Validē vs. Atļauja

> *"Sakiet godīgi — vai jūs meklējat ATĻAUJU, vai ATBALSTU? Parasti, kad esam 100% pārliecināti, sakām: 'Es to darīšu, un man būtu svarīgs tavs atbalsts'. Cik pārliecināts par šo risinājumu šobrīd jūtaties jūs pats skalā no 1 līdz 10?"*

### 2.3 IEBILDUMS: "MAN NAV LAIKA"

#### Skripts A — Laika Investīcijas Kadrēšana

> *"30 sekundes — ja pēc tam nešķiet vērtīgi, beidzam uzreiz. Godīgi?"*

#### Skripts B — COI Pārvēršana

> *"Tieši tāpēc šis ir tik svarīgi! Mūsu sistēma jums atbrīvos vidēji 12 stundas nedēļā. Tas ir 624 stundas gadā. Cik vērtīga ir jūsu stunda? [pauze]. Šī saruna varētu būt visu citu sarunu vērta jūsu kalendārā."*

### 2.4 IEBILDUMS: "ATSŪTIET MAN E-PASTU"

> *"Noteikti! Lai e-pasts būtu maksimāli noderīgs — kas svarīgāk: A vai B? Lai nosūtu precīzi to, kas atbild uz jūsu galveno jautājumu."*

### 2.5 IEBILDUMS: "MĒS JAU STRĀDĀJAM AR KĀDU CITU"

#### Skripts A — Slazda Jautājums

> *"Lieliska izvēle — [konkurents] ir spēcīgs [stiprā joma]. Daudzi klienti pārnāca pie mums tieši [mūsu unikālā priekšrocība] dēļ. Kā jūs šobrīd risiniet [konkurenta vājā vieta]?"*

#### Skripts B — Papildinājuma Stratēģija

> *"Tas ir saprotami, un es neprasu jums nomainīt partneri. Daudzi mūsu klienti sākotnēji arī strādāja ar [konkurentu] — viņi mūs izmanto KĀ PAPILDINĀJUMU, nevis kā aizstājēju. Vai būtu vērts 5 minūtes apskatīt, kā tas varētu izskatīties?"*

### 2.6 IEBILDUMS: "MAN PAR TO IR JĀPADOMĀ"

> *"Parasti, kad cilvēki saka 'jāpadomā', tas nozīmē vai nu 'nē', vai arī viņi nav pārliecināti. Kurā pusē esat jūs?"*

**Trap Close variants:**

> *"Pilnīgi saprotu. Bet pirms beidzam — jūs minējāt, ka pašlaik cīnāties ar [problēma]. Jūs teicāt, ka, ja tas netiks atrisināts, sekas būs [negatīvās sekas]. Un jūsu mērķis ir sasniegt [vēlamo rezultātu]. Tāpēc mans jautājums ir: **Kas tieši šodien ir jānotiek, lai šis rezultāts kļūtu par realitāti?**"*

---

## 3. SLĒGŠANAS TEHNIKAS
### Trīs Meistaru Metodes

### 3.1 KLUSĀ SLĒGŠANA (The Quiet Close)
**Princips:** Zemspriegs paņēmiens, kas testē apņemšanos bez agresīvas virzīšanas. Tu uzdod jautājumus un tad — KLUSI. Ļauj klusumam strādāt.

**3 soļu process:**

1. **Atdalī cenu no vērtības:**
> *"Noliekot cenu malā uz sekundi — vai mūsu risinājums atrisina jūsu problēmu?"* → Klients: "Jā"

2. **Saistī rezultātus:**
> *"Ja jūs iegūtu rezultātus X, Y un Z — vai tā būtu vērtīga investīcija?"* → Klients: "Jā"

3. **Klusa pauze:**
> *"Lieliski. Kāds būtu labākais veids, kā mēs varam sākt?"*
> **(KLUSUMS. Gaidi. Pirmais, kas runā — zaudē.)**

**Kāpēc tas strādā:** Klusums rada neērtību, kas motivē klientu runāt. Ja viņš jau divreiz teicis "jā", loģiskais nākamais solis ir virzīties uz priekšu.

### 3.2 SLAZDA SLĒGŠANA (The Trap Close)
**Princips:** Ar gudru jautājumu likšanu klients pats atklāj savas vajadzības un vājās vietas, "ieslodzot" sevi pozīcijā, kur tava prece ir acīmredzams risinājums.

**Pret konkurentu:**
> *"Prieks dzirdēt, ka jūs jau strādājat ar [konkurentu]. Viņi ir lieliski [stiprā puse]. Daudzi no mūsu klientiem pārnāca pie mums tieši [mūsu unikālā priekšrocība] dēļ. Kā jūs pašlaik risināt [konkurenta vājā vieta]?"*

**Vajadzību atklāšana:**
> *"Ja jūs varētu mainīt VIENU lietu savā pašreizējā [procesā/sistēmā/partnerībā] — kas tā būtu?"*

**Budžeta slazds:**
> *"Pieņemsim, ka cena nebūtu jautājums — vai jūs virzītos uz priekšu ar šo?"*
> Ja "jā" → problēma ir tikai cena, vari strādāt ar to.
> Ja "nē" → ir dziļāks iebildums, kas jāatklāj.

### 3.3 GALAMĒRĶA PREZENTĀCIJA (The Destination Pitch)
**Princips:** Fokusējies uz klienta sapņu galamērķi — ne uz produktu, bet uz DZĪVI pēc pirkuma. Belfort Straight Line: Uzmanība → Interese → Vēlme → Darbība.

**Emocionālais Galamērķis:**
> *"Iedomājieties — ir pēc 6 mēnešiem. Jūsu komanda strādā bez stresa, fokusējoties uz izaugsmi, nevis rutīnu. Jūsu ieņēmumi ir pieauguši par [X]%. Jūs beidzot varat koncentrēties uz to, kas JUMS ir svarīgi, nevis uz ugunsgrēku dzēšanu. Tas ir galamērķis, ko mēs kopā varam sasniegt. Vienīgais jautājums ir — vai mēs sākam šodien vai nākamnedēļ?"*

**Biznesa Galamērķis:**
> *"Nauda nav reāla — pieredze ir reāla. Šī investīcija nav par [produktu]. Tā ir par brīvību — brīvību no [problēma], brīvību fokusēties uz [klients vērtība], brīvību augt bez ierobežojumiem. Kur jūs vēlaties būt pēc gada? Ļaujiet man palīdzēt jums tur nokļūt."*

**Straight Line Slēgšana:**
> *"Balstoties uz visu, ko jūs man pastāstījāt — jūsu lielākā problēma ir [X], jūs vēlaties sasniegt [Y], un laiks ir svarīgs. Mūsu risinājums precīzi atbilst tam, kas jums vajadzīgs. Vienīgais, ko vēlos zināt — vai mēs esam gatavi sākt?"*

---

## 4. STEIDZAMĪBA UN BEZDARBĪBAS IZMAKSAS
### Kā Radīt Patiesu Steidzamību (Bez Manipulācijas)

### 4.1 Bezdarbības Izmaksu (COI) 5 Soļu Ietvars

**Princips:** Zaudējumi sāp DIVREIZ vairāk nekā līdzvērtīgi ieguvumi (Prospect Theory — Kahneman & Tversky). "Ko jūs ZAUDĒSIET gaidot" ir spēcīgāk nekā "ko jūs iegūsiet pērkot".

**1. Solis — Identificē "asiņojošo" metriku**
> *"Kāds rādītājs visvairāk cieš šobrīd šīs problēmas dēļ?"*

**2. Solis — Aprēķini viena mēneša bezdarbības izmaksas**
> *"Ja jūsu atbildes ātrums ir samazinājies no 8% uz 3%, cik tas izmaksā zaudētos pārdošanas mēnesī? Aprēķināsim kopā — [X] stundas × [Y] alga = [Z] EUR tukšā darbā."*

**3. Solis — Projicē 90 dienu izmaksas**
> *"Pirmais mēnesis: €[X]. Bet šeit ir runa ne tikai par naudu — pēc trīs mēnešiem jums ir arī pipeline trūkumi, komandas izdegšanas risks un tirgus daļas zaudējums. Kopā tas ir [3X+] EUR."*

**4. Solis — Rēķini DZĪVI zvana laikā**
> *"Darīsim matemātiku kopā tagad. Ko jūs zaudējat tieši šobrīd, kamēr mēs runājam? Šajās 30 minūtēs — €[Z]/30 = €[X] minūtē tukšā darba."*

**5. Solis — Cenas pretstats**
> *"Mūsu cena ir €[Y]. Salīdzinot ar €[3X] zaudējumiem nākamo 90 dienu laikā — jūs jau pirmajā mēnesī esat plusos."*

### 4.2 Steidzamības Skripti

> *"Gaidīšana nav bezmaksas. Katra diena bez šī risinājuma jums maksā [Laiku/Naudu/Stresu]. Vai mēs apturam šo dedzināšanu šodien?"*

> *"Aprēķināsim kopā — €[X] mēnesī zaudētos pārdošanas ieņēmumos nozīmē €[3X] zaudējumus nākamo 90 dienu laikā. Vai finalizējam šodien, lai apturētu šo dedzināšanu?"*

### 4.3 Patiesa vs. Manipulatīva Steidzamība

| ❌ Manipulācija (strādā vienreiz) | ✅ Patiesa Steidzamība (strādā vienmēr) |
|---|---|
| "Tikai šodien!" | "Katra diena bez risinājuma jums maksā €X" |
| "Tikai 3 vietas palika!" | "Mūsu komandas kapacitāte šajā ceturksnī jau ir 80% piepildīta" |
| "Cena rīt pieaugs!" | "Ja sākam šomēnes, jūs paspēsiet sasniegt mērķi pirms gada beigām" |

---

## 5. PSIHOLOĢIJA — LOJALITĀTE, SINEK, SERHANT

### 5.1 Simon Sinek — Sāc ar KĀPĒC

**Zelta loks:** KĀPĒC (mērķis/pārliecība) → KĀ (process/diferencators) → KO (produkts).

**Slikti (sākt ar KO):**
> "Mēs piedāvājam programmatūru, kas automatizē jūsu pārdošanu. Tā ir lētāka par konkurentiem un ar 10 funkcijām."

**Labi (sākt ar KĀPĒC):**
> "Mēs ticam, ka pārdošanas darbam jābūt par cilvēku attiecībām, ne par administratīvu darbu. Mēs cīnāmies pret to, ka pārdevēji 70% laika pavada manuālā darbā, nevis ar klientiem. Tāpēc mēs radījām [risinājumu] — jo katra stunda, kas tērēta CRM ievadē, ir stunda, kas zaudēta klientiem."

**Sinek atziņa:** *"Cilvēki nepērk to, ko tu dari — viņi pērk KĀPĒC tu to dari."*

### 5.2 Ryan Serhant — 3-F Sekošanas Sistēma

| Posms | Laiks | Darbība | Skripts |
|---|---|---|---|
| **Follow Up** | +10 min | Ziņa pēc tikšanās | "Prieks bija tikties pirms 7,5 minūtēm! Jūsu [X] palika prātā." |
| **Follow Through** | +1 līdz +3 dienas | Izpildi solīto | "Šeit ir [analīze/dati], ko apsolīju." |
| **Follow Back** | +30 dienas | Atgriezies ar JAUNU vērtību | "Saredzu jaunu rakstu par [tava nozare] — palika prātā mūsu saruna." |

**Serhant likums:** *"Lielākā daļa pārdevēju seko 1-2 reizes un padodas. Es sekoju 50 reizes — un tāpēc esmu labākais."*

### 5.3 Lojalitātes Cilpa — The Post-Sale Wow

**24h Check-in:** Piezvani 24h pēc piegādes, pajautā tikai *"Vai viss kārtībā?"* — nepārdod neko jaunu.

**Rezultāts:** Nogalina pircēja nožēlu, radikalizē klientu par tavu fanu.

---

## 6. DOMINO SKRIPTS — PILNĀ SISTĒMA

### Domino 8 soļi:

1. **Uzmanība** — atvērt smadzenes
2. **Sāpes** — atklāt problēmu
3. **Pastiprinājums** — padziļināt sāpes (COI)
4. **Galamērķis** — pārdod sapni, ne produktu
5. **Pierādījums** — case study, sociālais pierādījums
6. **1. Slēgšana** — testē apņemšanos
7. **Loop** — apstrādā iebildumus
8. **Galīgā Slēgšana** — collapse + klusums

### Pilnais Domino Skripts (15-20 min)

#### 1. solis — Uzmanība
> *"[Vārds], pirms turpinām — vai varu uzdod vienu jautājumu? Kas jūs pamudināja atvēlēt laiku šai sarunai tieši tagad, nevis pirms 6 mēnešiem?"*

#### 2. solis — Sāpes
> *"Cik ilgi jūs jau esat tādā situācijā? Ko tas jums ir izmaksājis — naudā, laikā, enerģijā?"*

#### 3. solis — Pastiprinājums (COI)
> *"Ja nekas nemainās, kur jūs būsiet pēc 6 mēnešiem? Pēc gada? Vai tas ir akceptējami?"*

#### 4. solis — Galamērķis
> *"Iedomājieties — ir pēc 6 mēnešiem. [X], [Y], [Z]. Vai tas ir tas, kur gribat būt?"*

#### 5. solis — Pierādījums
> *"[Uzņēmums Y] bija tieši tādā pašā situācijā. Pēc [Z] mēnešiem viņu [metrika] uzlabojās par [%]. Konkrēti — [detalizēts piemērs]."*

#### 6. solis — 1. Slēgšana
> *"Vai redzat, kā tas varētu strādāt arī jums? [Pauze.] Kāds būtu labākais veids, kā mēs varam sākt?"*

#### 7. solis — Loop (iebildumu apstrāde)
> Apstrādā ar VAI formulu (Validē → Atdalī → Interpretē).

#### 8. solis — Galīgā Slēgšana
> *"Ņemot vērā visu, ko esam apsprieduši — vai jūs esat gatavi virzīties uz priekšu? Kādu kredītkarti mēs izmantosim?"*
> **(KLUSUMS.)**

---

## 7. 6 IEBILDUMI 60 SEKUNDĒS

| # | Iebildums | Atbilde (≤10 sek) |
|---|---|---|
| 1 | 💰 **Par dārgu** | *"Cik izmaksā KATRU MĒNESI BEZ risinājuma? Mūsu cena < 1 mēneša zaudējumi."* |
| 2 | 👫 **Jārunā ar partneri** | *"Vai PATS esi pārliecināts? Jā? Sagatavosim viņa jautājumus kopā."* |
| 3 | ⏰ **Nav laika** | *"30 sek tests — ja nav vērtīgi, beidzam. Godīgi?"* |
| 4 | 📧 **Nosūtiet e-pastu** | *"Noteikti! Kas svarīgāk: A vai B? Lai nosūtu precīzi."* |
| 5 | 🤝 **Jau strādā ar citu** | *"Kas padodas? Kas varētu būt labāk? Mēs = papildinājums."* |
| 6 | 🤔 **Jāpadomā** | *"Par ko tieši? Lai sniegtu info lēmumam."* |

---

## 8. IKDIENAS PĀRDOŠANAS RITUĀLI

### Rīta rituāls (15 min)
- 5 min: Pārskati šodienas darījumus.
- 5 min: Trenē 6 iebildumu atbildes 60 sekundēs.
- 5 min: Vizualizē veiksmīgu sarunu.

### Pirms zvana (2 min)
- Power Pose (krūtis uz priekšu, rokas sānos).
- Smaids (klients var "dzirdēt" smaidu).
- Mantra: *"Es nestrādāju ar visiem. Man tas nav VAJADZĪGS."*

### Pēc zvana (5 min)
- Pieraksti CRM: ko klients teica, kādi nākamie soļi.
- Sūti follow-up ziņu pēc 10 min (Serhant 3-F #1).
- Ja "Nē" — atceries 10:3:1 statistiku, neuztver personīgi.

### Vakara rituāls (10 min)
- Pārskati dienas zvanus, pieraksti 1 lietu, ko darīt labāk rīt.
- Plāno rītdienas pipeline (vienmēr 25-30 atvērti darījumi).
- Klausies 3-5 min audio rokasgrāmatu pirms gulētiešanas.

---

## PIELIKUMS A: ĀTRĀS REFERENCES KARTĪTE
*(Pilns saturs — sk. atsevišķo dokumentu QUICK_REFERENCE.pdf)*

---

## PIELIKUMS B: SKRIPTU VEIDNES REĀLĀM SITUĀCIJĀM

### B.1 Aukstā Zvana Skripts (Pilns)

> Tu: *"Labdien, [vārds]! Es zvanu ar ļoti specifisku iemeslu — un man vajag tikai 90 sekundes. Vai varu?"*
> [Ja jā]
> Tu: *"Mēs strādājam ar uzņēmumiem jūsu nozarē, un mēs atrisinājām problēmu, kas, iespējams, skar arī jūs — [konkrēta problēma]. Piemēram, [uzņēmums X] pirms 3 mēnešiem bija tādā pašā situācijā. Viņi tagad redz [konkrēts rezultāts]. Vai jums ir 5 minūtes šonedēļ, lai paskatītos, vai mēs varam sasniegt līdzīgu rezultātu jums?"*

### B.2 Tikšanās Skripts (Pilns, Sinek + Domino)

**Sākums (KĀPĒC):**
> *"Pirms es jums kaut ko rādu — ļaujiet man pastāstīt, kāpēc mēs darām to, ko darām. Mēs ticam, ka [KĀPĒC]. Tas mūs iedvesmoja radīt [risinājumu]."*

**Izpēte (SĀPES):**
> *"Bet pirms es stāstu vairāk — gribu saprast JŪSU situāciju. Kāda ir lielākā problēma, kas jūs kavē sasniegt [mērķi]? Cik ilgi tā pastāv? Ko tā jums izmaksā — naudā, laikā, stresā?"*

**Risinājums (KĀ + KO):**
> *"Balstoties uz to, ko dzirdu — šeit ir tas, kā mēs to risinām. [KĀ — unikālais process]. Un rezultāts ir [KO — produkts]. Bet jūs nepērkat produktu — jūs iegūstat [GALAMĒRĶIS]."*

**Pierādījums:**
> *"[Uzņēmums Y] bija tieši tādā pašā situācijā. Pēc [Z] mēnešiem viņu [metrika] uzlabojās par [%]."*

**Slēgšana:**
> *"Vai esat gatavs veikt nākamo soli?"* **(KLUSUMS)**

### B.3 Follow-Up E-pasta Veidne

> **Temats:** Par mūsu sarunu + [viens konkrēts datu punkts]
>
> Sveiki [Vārds],
>
> Paldies par šodienas sarunu! Šeit ir apsolītā [analīze/dati/materiāls].
>
> Kā pieminēju — [uzņēmums X] jūsu nozarē redzēja [konkrēts rezultāts] [Y] mēnešu laikā. Balstoties uz to, ko pastāstījāt par [viņu problēmu], es ticu, ka līdzīgs rezultāts ir reāls arī jums.
>
> Nākamais solis būtu [konkrēta darbība]. Vai [diena] plkst. [laiks] ir piemērots?
>
> [Tavs vārds]
>
> P.S. Pievienoju arī [bonusa vērtība — raksts, dati, insights], kas varētu būt noderīgs neatkarīgi no mūsu sadarbības.

---

## PIELIKUMS C: PSIHOLOĢISKO TRIGERU ENCIKLOPĒDIJA

| # | Trigeris | Apraksts | Piemērs Skriptā |
|---|---|---|---|
| 1 | **Zaudējumu Izvairīšanās** | Cilvēki riskē vairāk, lai IZVAIRĪTOS no zaudējumiem | *"Katrs mēnesis bez risinājuma izmaksā €X"* |
| 2 | **Sociālais Pierādījums** | Cilvēki seko tam, ko dara citi | *"87% nozares līderu jau izmanto šo pieeju"* |
| 3 | **Autoritātes Efekts** | Cilvēki uzticas ekspertiem | *"Mūsu 15 gadu pieredze šajā jomā liecina..."* |
| 4 | **Retums/Trūkums** | Ierobežots = vērtīgāks | *"Šobrīd mēs pieņemam tikai 3 jaunus klientus ceturksnī"* |
| 5 | **Savstarpēja Atdeve** | Ja dod — saņem | Sniedz VĒRTĪBU pirms jebkādas prasības |
| 6 | **Apņemšanās/Konsekvence** | Mazas "jā" ved uz lielo "jā" | "Trīs Jā" tehnika pirms cenas |
| 7 | **Piederības Sajūta** | Vēlme piederēt grupai | *"Mūsu klienti ir kopiena, nevis saraksts"* |
| 8 | **Stāstu Spēks** | Stāsti > fakti | Vienmēr izmanto klientu veiksmes stāstus |
| 9 | **Kontrasts** | Cena šķiet mazāka blakus lielākam skaitlim | *"€2,500 vs €35,000 gadā par darbinieku"* |
| 10 | **Pirmā/Pēdējā Iespaids** | Atceras sākumu un beigas | Sāc ar WOW, beidz ar skaidru nākamo soli |
| 11 | **Ankurēšana** | Pirmais skaitlis nosaka gaidīšanas | Vispirms min augstāko vērtību/cenu |
| 12 | **Zeigarnik Efekts** | Nepabeigtas lietas paliek prātā | Atstāj "cliffhanger" — info, ko saņems nākamreiz |
| 13 | **IKEA Efekts** | Cilvēki vērtē to, ko palīdzēja veidot | Iesaisti klientu risinājuma izstrādē |
| 14 | **Kadrēšana** | Konteksts maina uztveri | *"Investīcija"* vs *"izmaksas"* |
| 15 | **Pirmtecēja Priekšrocība** | Pirmais = labākais | *"Jūs būsiet pirmais savā nozarē, kas to ievieš"* |

---

## PIELIKUMS D: NOSLĒGUMA ATGĀDNES — 10 ZELTA LIKUMI

1. **Nekad nepārdod no izmisuma.** Pildi pipeline, ne ego.
2. **Sāc ar KĀPĒC.** Produkts ir pēdējais, ko piemin.
3. **Klausies 70%, runā 30%.** Labākie pārdevēji ir labākie klausītāji.
4. **Aprēķini bezdarbības izmaksas KOPĀ ar klientu.** Tas rada steidzamību bez manipulācijas.
5. **Sekojums ir VISS.** Follow up, follow through, follow back — mūžīgi.
6. **Klusums slēdz darījumus.** Pēc slēgšanas jautājuma — KLUSI.
7. **Trīs desmitnieki.** Produkts, Tu, Uzņēmums — visi 10/10.
8. **Esi padomdevējs, ne pārdevējs.** Uzticēšanās > darījums.
9. **Validē → Atdalī → Interpretē** (VAI). Katrs iebildums = framework.
10. **Klients pats izlemj.** Tu tikai vadi viņu līdz patiesam atklājumam.
