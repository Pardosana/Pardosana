# 📚 ARTEFAKTS #3 · ARHĪVS — VISI AVOTI

> **Šī ir V15.1 sistēmas izejas materiāli vienā vietā.** Visi 93 video transkripti, 2 audio faili (oriģināli + transkripti), Lawrence editorial dump, chat avoti, atsauces PDF.

---

## Kas ir iekšā

| Fails | Apjoms | Saturs |
|---|---|---|
| `transcripts_93_IGFB.tar.gz` | 80 KB | 93 IG/FB video transkripti JSON formātā (84 EN + 8 LV + 1 PT) |
| `algoritms.txt` | 21 KB | Whisper transkripts: SalesEngine_algoritms_preczai_lmumu_pieemanai (88 min) |
| `hopefog.txt` | 21 KB | Whisper transkripts: Shattering_the_high_ticket_hope_fog (36 min) |
| `AUDIO_SalesEngine_algoritms.m4a` | 41 MB | Oriģinālais audio fails (NotebookLM par lēmumu algoritmu) |
| `AUDIO_hope_fog_shatterer.m4a` | 38 MB | Oriģinālais audio fails (NotebookLM par Hope Break) |
| `REFERENCE_SalesEngine_Master_Schematic.pdf` | 17 MB | Google NotebookLM vizuāls atskats uz V14.1 (17 lpp) |
| `REFERENCE_man_vajag_100procentu_pabeigtu.pdf` | 31 MB | Lauris vadlīnijas par V15.1 build (287 lpp) |
| `chat_dump.md` | 6 KB | Chat dialogs ar editorial editoru |
| `lawrence_manual.md` | 23 KB | Lawrence editorial dump (Belfort/Serhant/Sinek/Voss) |

**Kopā: 9 faili, ~127 MB.**

---

## Kā šie avoti ievadīti V15.1

### 93 IG/FB transkripti → Daļa VII Validācijas statistika
- **305 atsauces** uz V14.1 mezgliem
- **Top 10 outside-validēti:** WHY=32, PITCH=31, PRICE=26, MICE=20, HOPE BREAK=19...
- **84 EN videos** → izgāja EN→LV pipeline (literal → adapted → 5-māju filtrs)
- **8 LV videos** → izvilkti tieši (Lauris signature)

### Audio "algoritms" → Daļa VIII Lēmumu Algoritms
- 7-soļu klienta iekšēja ķēde
- System 1/2 (Kahneman) integrācija
- Diagnostika: ja iesprūst → atgriezies pie iepriekšējā soļa

### Audio "hopefog" → Daļa IX Hope Fog Shatterer Deep
- Q21.5 mehāniska detalitāte: 3 kāpnes
- 7 MICE-adaptīvas frāzes
- 10. metafora "Spēļu automāts vs konveiers"

### Master Schematic PDF → Daļa X Blueprint Atlanta
- Outside-view audit no NotebookLM
- 17 strukturālie skati uz V14.1
- V15.1: pārbūvēti par 12 LV oriģinālām blueprint shēmām

### Lawrence editorial dump → Daļa VI Validētais Arsenāls
- Belfort tonalitāte (5 balsis)
- Serhant 3-F sekošana
- Sinek WHY/HOW/WHAT
- Voss "Nē" psiholoģija
- 11 jauni mezgli izgāja 5-māju filtru

---

## Kā paplašināt arhīvu (turpmāka pētniecība)

```bash
# Atvērt 93 transkriptus
tar xzf transcripts_93_IGFB.tar.gz
ls transcripts/ | head -20

# Atskaņot audio (lai dziļāk saprastu)
mpv AUDIO_SalesEngine_algoritms.m4a
mpv AUDIO_hope_fog_shatterer.m4a

# Pārbaudīt audio transkriptus
less algoritms.txt
less hopefog.txt
```

---

## Validācijas filozofija

> *Katrs avots iet caur 5-māju filtru pirms ielikšanas V15.1 grāmatā:*
>
> 1. Vai tas iet **CORE** (Q1-Q40 skripts)?
> 2. Vai tas iet **CURRENT CORK** (kabatas slānis)?
> 3. Vai tas ir **ARSENAL** (situatīvs paņēmiens)?
> 4. Vai tas iet **TRAINING** (operators mācās)?
> 5. Vai tas ir **SPECIAL CASE** (anomālija)?
> 6. Vai tas ir **CARRIER** (vizuālā metafora)?
>
> Ja **nesader nevienā mājā** → izmests. Ja **dublē V14.1** → izmests. Ja **pievieno jaunu leņķi** → integrēts ar avota signātūru.

**Šajā arhīvā ir gan IZMANTOTAIS, gan NEIZMANTOTAIS materiāls** — tāpēc tas ir reference, ne galvenais dokuments.
