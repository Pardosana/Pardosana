# PIELIKUMI E: 11 "SLEPENIE" PĀRDOŠANAS PAŅĒMIENI
## (No Lawrence chat-dump, papildus PDF)

Šie ir nianses, kas parasti paliek starp rindām video materiālos, bet padara tevi par 1% labāko pārdevēju pasaulē.

### 1. Tonitāte — nevis KO tu saki, bet KĀ tu saki
Jordan Belfort (Straight Line) uzsver 3 galvenās balsis:

- **"Ieskaitot noslēpumu" (Whisper):** Kad saki cenu vai īpašu piedāvājumu, nedaudz samazini balsi, it kā tu atklātu noslēpumu. Tas liek klientam pievirzīties tuvāk un klausīties uzmanīgāk.
- **"Absolūta pārliecība":** Nekādu "varbūt" vai "es domāju". Tavai balsij ir jāskan tā, it kā tu paziņotu, ka rīt lēks saule.
- **"Saprātīgums":** Beigās vienmēr pajautā: *"Vai tas izklausās godīgi?"* ar mierīgu, saprātīgu toni.

### 2. Mikro-apstiprinājumi (The "Yes" Momentum)
Negaidi līdz beigām, lai saņemtu "Jā". Iesēj mazus "jā" ik pēc 2-3 minūtēm:

- *"Vai šis punkts jums ir skaidrs?"*
- *"Vai piekrītat, ka šis ietaupītu jūsu laiku?"*
- *"Vai redzat, kā tas saskan ar jūsu mērķiem?"*

**Kāpēc tas strādā:** Cilvēka smadzenēm ir grūtāk pateikt "Nē" lielajam darījumam, ja tās tikko ir pateikušas 10 mazus "Jā".

### 3. "Ghosting" apkarošana (Ja klients pazūd)
Ja klients neatbild uz e-pastiem vai zvaniem, izmanto Ryan Serhant **"Break-up"** metodi:

> *"Sveiki, [Vārds]. Tā kā neesmu saņēmis ziņu, pieņemu, ka jūsu prioritātes ir mainījušās vai esat izvēlējušies citu ceļu. Es slēdzu šo lietu savā sistēmā, lai vairs jūs netraucētu. Ja situācija mainās, zināt, kur mani atrast."*

**Rezultāts:** ~80% gadījumu klients atbild uzreiz, jo neviens neizmanto "atņemšanas" taktiku.

### 4. Kontrasta enkurošana (Cenas psiholoģija)
Pirms saki savu cenu, piemini lielāku skaitli, kas nav saistīts ar preci:

> *"Daudzi uzņēmumi tērē €50,000 gadā par šādu procesu uzturēšanu manuāli. Mūsu pilnā automatizācija, kas to visu aizstāj, ir tikai €2,500."*

**Rezultāts:** €2,500 pēkšņi izskatās kā nieks salīdzinājumā ar €50,000.

### 5. Atņemšana (The Takeaway Close)
Ja klients sāk pārāk daudz šaubīties, tu esi tas, kurš paņem piedāvājumu atpakaļ:

> *"Ziniet, [Vārds], man sāk šķist, ka šis risinājums šobrīd nav jums piemērots. Jūs neesat gatavi [X] izmaiņām, un es negribu, lai jūs tērējat naudu bez rezultāta. Varbūt atgriežamies pie šī pēc gada?"*

**Rezultāts:** Acumirklī rada milzīgu vēlmi pēc produkta — "aizliegtais auglis ir saldāks".

### 6. Pārdošanas ķermeņa valoda (Zoom un klātienes tikšanās)
Pat ja klients tevi neredz (zvanā), ķermeņa valoda maina tavu balsi.

- **The Power Pose:** Pirms zvana nostājies uz 2 minūtēm "Supermeņa" pozā (rokas sānos, krūtis uz priekšu). Zinātniski palielina testosteronu un samazina kortizolu.
- **Smaids zvanot:** Klienti var "dzirdēt" smaidu. Tas padara toni siltāku un uzticamāku.
- **Acu kontakts (70/30 likums):** 70% laika skaties acīs, 30% laika prom — lai klients nejustos "medīts".
- **Spoguļošana (Mirroring):** Nedaudz (neuzkrītoši) atkārto klienta pozu un runas ātrumu. Ja viņš runā lēni un mierīgi, arī tu tā dari.

### 7. "Es aprunāšos ar vadību" (CEO Objection)
Ja klients nav galvenais lēmumu pieņēmējs:

> *"Es pilnīgi saprotu. Bet, lai jūsu vadītājam nebūtu jātērē laiks, mēģinot uzminēt mūsu sarunas detaļas — vai būtu jēga man pievienoties uz 5 minūtēm jūsu nākamajā tikšanās reizē? Es varu atbildēt uz visiem tehniskajiem jautājumiem uzreiz, lai jūs izskatītos kā varonis, kurš atradis risinājumu."*

**Kāpēc tas strādā:** Tu kļūsti par viņa sabiedroto, nevis pārdevēju.

### 8. Lojalitātes cilpa (The Post-Sale Wow)
Pārdošana beidzas nevis ar maksājumu, bet ar klienta pirmo rezultātu:

- **The 24h Check-in:** Piezvani 24 stundas pēc tam, kad klients ir saņēmis preci/pakalpojumu. Tikai pajautā: *"Vai viss ir kārtībā un vai varu vēl ko palīdzēt?"* Nepārdod ne ko jaunu.

**Rezultāts:** Nogalina "pircēja nožēlu" un radikalizē klientu par tavu fanu, kurš tevi ieteiks citiem.

### 9. Manipulācija vs. Inspirācija (Sinek dziļā atziņa)
- **Manipulācija:** *"Pērc tagad, jo rīt cena būs par 50% dārgāka!"* (Strādā vienreiz.)
- **Inspirācija:** *"Mēs strādājam pie šī, jo ticam, ka [X] nozarei ir jāmainās. Mēs meklējam partnerus, kuri tic tam pašam."* (Strādā mūžīgi.)

**Ieteikums:** Izmanto manipulāciju (atlaides, termiņus) tikai pašās beigās, lai paātrinātu lēmumu. Nekad neizmanto to kā galveno iemeslu, kāpēc pirkt.

### 10. "Nē" psiholoģija (Chris Voss — Never Split the Difference)
Nekad nebaidies no "Nē". "Nē" ir sarunas sākums, nevis beigas.

- *"Vai būtu smieklīgi, ja mēs apsvērtu iespēju strādāt kopā?"* (Vieglāk pateikt "Nē, tas nebūtu smieklīgi", kas nozīmē "Jā, apsveram".)
- *"Vai jūs esat pret to, lai mēs uzlabotu jūsu efektivitāti?"* (Atbilde: "Nē" = "Esmu par".)

### 11. AI un automatizācija — tavas "superspējas"
- **Satura mašīna:** Izmanto AI, lai pārveidotu vienu veiksmīgu sarunu par 10 sociālo tīklu ierakstiem.
- **CRM disciplīna:** Ja tas nav pierakstīts CRM, tas nav noticis. Izmanto AI, lai transkribētu zvanus un uzreiz izvilktu "Nākamos soļus".

---

## PIELIKUMS F: 3 ZELTA ATZIŅAS

### 1. 10:3:1 Atteikumu attiecība (Psiholoģiskā noturība)
Lai tiktu pie 1 uzvaras, vidēji vajag **10 kontaktus** un **3 padziļinātas sarunas**.

**Kāpēc tas ir svarīgi:** Ja saņem "Nē", tu nezaudē — tu esi par vienu soli tuvāk tam vienam "Jā". Neuztver to personīgi. Tā ir tikai statistika.

### 2. "Zelta stundas" likums (Follow-up ātrums)
Ja klients izrāda interesi (piem., aizpilda formu), tava iespēja noslēgt darījumu ir **100 reizes lielāka**, ja sazinies pirmajās **5 minūtēs**, nekā ja gaidi stundu.

**Darbība:** Neplāno zvanu uz rītdienu. Zvani uzreiz, kamēr klienta smadzenes vēl ir "pārdošanas temperatūrā".

### 3. Pārdošana caur Referāļiem
Skripts pēc darījuma:

> *"Klau, [Vārds], esmu priecīgs, ka sākām strādāt. Mans mērķis ir padarīt tevi tik apmierinātu, ka tu gribēsi mani ieteikt visiem saviem partneriem. Vai ir kāds uzņēmums tavā lokā, kuram šobrīd arī deg [Problēma X]?"*

**Rezultāts:** Viens apmierināts klients var atvest 3 jaunus bez reklāmas izmaksām.
