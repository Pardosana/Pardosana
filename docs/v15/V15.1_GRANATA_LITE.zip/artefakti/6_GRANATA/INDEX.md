# 💣 GRANĀTA PILNA · V15.1 MASTER INDEX

> **Šī ir visa V15.1 sistēma vienā mega-pakotē. 8 artefakti vienā vietā.**

---

## Saturs

| # | Artefakts | Mērķis | Atvērt |
|---|---|---|---|
| 1 | 🏛️ **IZVĒRSTAIS KOLOSS** | Pilnā V15.1 dokumentācija (Premium Book + atlas + atvasinājumi) | `1_KOLOSS/` |
| 2 | ⚙️ **CORE** | Kanonīsks pamats (V14.1 sacrosanct + cork + kodons) | `2_CORE/` |
| 3 | 📚 **ARHĪVS** | Visi avoti (93 transkripti + 2 audio + Lawrence + references) | `3_ARHIVS/` |
| 4 | 🎓 **SKILL** | 30-dienu apmācības kit | `4_SKILL/` |
| 5 | 🤖 **AI COACH** | Master prompt + 3 testa scenāriji | `5_AI_COACH/` |
| 6 | 💣 **GRANĀTA PILNA** | Šī pati — index uz visu | `6_GRANATA/` |
| 7 | 🎬 **PREZENTĀCIJA** | 21 slaidu V15.1 deck | `7_PREZENTACIJA/` |
| 8 | 🌐 **WEB APP** | Live URL + lokālais snapshot | `8_WEB/` |

---

## Quick Start (5 min)

### Ja tu esi Lauris (V15.1 īpašnieks)
1. Atver `1_KOLOSS/V15_PREMIUM_BOOK.pdf` — tava sistēma
2. Atver `7_PREZENTACIJA/V15_1_PREZENTACIJA.pdf` — 21 slaidu pārskats
3. Drukā `2_CORE/V15_OPERATOR_CORK.pdf` — kabatas slānis
4. Klausies `4_SKILL/V15_PRECALL_RITUAL_audio.mp3` pirms zvana

### Ja tu esi jauns operators
1. Sāc ar `4_SKILL/README.md` — 30-dienu programma
2. Lasi `1_KOLOSS/V15_PREMIUM_BOOK.pdf` Daļa I-II (90 min)
3. Atver `4_SKILL/roleplay.html` — drill simulators
4. Pēc 7 dienām sāc live zvanus ar `2_CORE/V15_OPERATOR_CORK.pdf` blakus

### Ja tu esi klients (potenciāls)
1. Skaties `7_PREZENTACIJA/V15_1_PREZENTACIJA.pdf` — 21 slaidi
2. Lasi `1_KOLOSS/V15_PRICING_TIERS.pdf` — 4 cenu līmeņi
3. Atver `8_WEB/README.md` — live URL ar interaktīviem rīkiem

### Ja tu esi investors / partneris
1. Lasi `1_KOLOSS/README.md` un `2_CORE/README.md`
2. Skaties `3_ARHIVS/README.md` — dziļums pieejamais materiāls
3. Pārbaudi live URL (`8_WEB`) — gatavs produkts

---

## Apjoma kopsavilkums

| Kategorija | Skaits | Apjoms |
|---|---|---|
| PDF dokumenti | ~15 | ~3 MB |
| Audio MP3 | 6 | ~16 MB |
| HTML interaktīvi rīki | 2 | ~70 KB |
| Markdown avoti | ~10 | ~250 KB |
| Reference oriģināli | 2 | 48 MB (audio) + 48 MB (PDF) |
| 93 transkripti | 1 tar.gz | 80 KB |
| **KOPĀ** | **~135 faili** | **~115 MB** |

---

## V15.1 papildinājumi (VS V15)

| Papildinājums | Detaļas |
|---|---|
| 🎙️ Edge Neural TTS | espeak-ng → lv-LV-NilsNeural (dabīga LV balss) |
| 🎨 12 oriģinālas LV blueprints | 17 NotebookLM EN JPGs aizvietoti |
| 🖨️ A3 whiteboard šabloni | 4 jauni printable PDF klientiem |
| 💰 4 pricing tieri | Basic €1.5k / Pro €3k / Ent €6k / WL €15k+ |
| 🎭 6 customer arhetipi | Detalas playbook ar Q-skriptiem |
| 🧬 Knowledge Graph | Interactive web app |
| 🎮 Roleplay Drill | 6 arhetipi, AI feedback 0-100 |
| 🎙️ Pre-Call ritual audio | 90 sek neirālā balss |

---

## V14.1 INTEGRITATĒ

✅ **V14.1 LV_MASTER_SCRIPT.md (2128 līnijas) ir BYTE-FOR-BYTE neaizskarta**

Visas V15/V15.1 izmaiņas ir **PIEVIENOJUMI**, ne aizvietojumi:
- Daļas I-V (V14.1 kanons) — pārvietoti tieši ar `slice_lines()`
- Daļas VI-XI (V15 jaunais) — pievienoti kā ārējie slāņi
- Daļas XII-XIII (V14.1) — pārvietoti tieši ar `slice_lines()`

---

## Process garantijas

Katrs V15.1 elements izgāja:

1. **5-māju filtru** — vai der CORE / CORK / ARSENAL / TRAINING / SPECIAL / CARRIER?
2. **EN→LV pipeline** — literal → adapted Latvijas tirgum + Lauris balss tonī
3. **De-duplikāciju** — ja jau V14.1 → izmests
4. **Audita pēdas** — avota signātūra (kāds IG video / kurš autors / kurš datums)
5. **5x review** — Domino architect / Editor / Translator / Skeptic / Publisher

---

> **Šī ir V15.1 finālā versija. Visi 8 artefakti FINAL kvalitātē.**
>
> **Lieto. Testē. Ja kas jāpielabo — pasaki.**
>
> *Lauris Leitāns / Sharpify.io · 2026 · V15.1*
