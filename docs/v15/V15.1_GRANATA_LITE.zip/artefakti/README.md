# 🎯 SALESENGINE V15.1 · 8 ARTEFAKTI · FINĀLĀ VERSIJA

> **Visi 8 artefakti FINAL kvalitātē.** Atver `6_GRANATA/INDEX.pdf` lai redzētu pilno karti.

---

## Mape

```
artefakti/
├── README.md                            ← ŠEIT (tu šobrīd to lasi)
├── 1_KOLOSS/                            🏛️ Izvērstais Koloss (Premium Book + atlas)
│   ├── README.md
│   ├── V15_PREMIUM_BOOK.pdf (107 lpp)
│   ├── V15_PREMIUM_BOOK.md
│   ├── V15_BLUEPRINT_ATLAS.pdf
│   ├── V15_WHITEBOARD_TEMPLATES_A3.pdf
│   ├── V15_PRICING_TIERS.pdf
│   ├── V15_CUSTOMER_ARCHETYPES.pdf
│   └── V15_CHANGELOG.pdf
├── 2_CORE/                              ⚙️ Kanonīsks pamats (V14.1 sacrosanct)
│   ├── README.md
│   ├── LV_MASTER_SCRIPT_V14_1.md
│   ├── V14.1_PREMIUM_BOOK_REFERENCE.pdf
│   ├── V15_OPERATOR_CORK.pdf
│   ├── V15_KODONS.pdf
│   └── V15_QUICK_REFERENCE.pdf
├── 3_ARHIVS/                            📚 Visi avoti (transkripti, audio, references)
│   ├── README.md
│   ├── transcripts_93_IGFB.tar.gz
│   ├── algoritms.txt
│   ├── hopefog.txt
│   ├── AUDIO_SalesEngine_algoritms.m4a
│   ├── AUDIO_hope_fog_shatterer.m4a
│   ├── REFERENCE_SalesEngine_Master_Schematic.pdf
│   ├── REFERENCE_man_vajag_100procentu_pabeigtu.pdf
│   ├── chat_dump.md
│   └── lawrence_manual.md
├── 4_SKILL/                             🎓 30-dienu apmācības kit
│   ├── README.md
│   ├── V15_OPERATOR_CORK.pdf + .mp3
│   ├── V15_KODONS.pdf + .mp3
│   ├── V15_QUICK_REFERENCE.pdf + .mp3
│   ├── V15_PRECALL_RITUAL_audio.mp3
│   ├── V15_CUSTOMER_ARCHETYPES.pdf
│   ├── V15_WHITEBOARD_TEMPLATES_A3.pdf
│   ├── roleplay.html
│   └── knowledge_graph.html
├── 5_AI_COACH/                          🤖 AI Coach prompt + 3 testa scenāriji
│   ├── README.md
│   ├── V15_AI_COACH_PROMPT.pdf
│   └── V15_AI_COACH_PROMPT.md
├── 6_GRANATA/                           💣 Master index uz visu (granāta pilna)
│   ├── INDEX.pdf
│   └── INDEX.md
├── 7_PREZENTACIJA/                      🎬 21 slaidu V15.1 deck
│   ├── README.md
│   ├── V15_1_PREZENTACIJA.pdf
│   └── V15_1_PREZENTACIJA.html
└── 8_WEB/                               🌐 Live URL + lokālais snapshot
    ├── README.md
    ├── index_root.html
    └── v15_snapshot/ (visi v15 web app faili)
```

---

## Quick Start (3 ceļi)

### 🚀 Ceļš #1 · "Es vēlos sākt LIETOT V15.1 TAGAD"
1. `2_CORE/V15_KODONS.pdf` — turi galvā kā kodu (5 min lasīt, 1 lapa)
2. Drukā `2_CORE/V15_OPERATOR_CORK.pdf` — kabatas slānis
3. Klausies `4_SKILL/V15_PRECALL_RITUAL_audio.mp3` pirms zvana (90 sek)
4. Sāc zvanu — sistēmas valoda jau strādā tev

### 🎓 Ceļš #2 · "Es vēlos APGŪT V15.1 sistemātiski"
1. `4_SKILL/README.md` — 30-dienu programma
2. Sāc 1. dienā · seko plānam
3. Pēc 30 dienām → V15 Eksperts

### 🏛️ Ceļš #3 · "Es vēlos REDZĒT visu sistēmu vienā skatienā"
1. `7_PREZENTACIJA/V15_1_PREZENTACIJA.pdf` — 21 slaidu pārskats (10 min)
2. `1_KOLOSS/V15_BLUEPRINT_ATLAS.pdf` — 12 vizuālas shēmas (10 min)
3. `6_GRANATA/INDEX.pdf` — master karte (5 min)

---

## V15.1 = V14.1 + 3 ārējie slāņi

```
┌────────────────────────────────────────────────┐
│  V14.1 KANONS (sacrosanct, byte-for-byte)      │ ← 2_CORE
│  Q1-Q40 · V8 · V13 · CARE · MICE              │
└────────────────────────────────────────────────┘
                      ⬇
┌────────────────────────────────────────────────┐
│  Slānis 1 · PIERĀDĪJUMI                        │ ← 3_ARHIVS
│  305 atsauces 93 IG/FB skriptos                │
└────────────────────────────────────────────────┘
                      ⬇
┌────────────────────────────────────────────────┐
│  Slānis 2 · ARSENĀLS                           │ ← 1_KOLOSS Daļa VI
│  11 jauni mezgli (LV adaptēti, 5-māju filtri)  │
└────────────────────────────────────────────────┘
                      ⬇
┌────────────────────────────────────────────────┐
│  Slānis 3 · VIZUĀLAIS ATLANTA                  │ ← 1_KOLOSS Daļa X
│  12 LV oriģinālas blueprint shēmas             │
│  + 4 A3 šabloni klientiem                      │
└────────────────────────────────────────────────┘
                      ⬇
┌────────────────────────────────────────────────┐
│  V15.1 PRAKSE                                  │ ← 4_SKILL + 5_AI_COACH + 8_WEB
│  Apmācības + AI Coach + Roleplay + Knowledge Graph │
└────────────────────────────────────────────────┘
```

---

## Apjoms

- **Faili:** ~135
- **Lapas (drukājamas):** ~250
- **Audio:** ~16 MB (Edge Neural LV)
- **Reference materiāls:** ~95 MB (audio + PDF)
- **KOPĀ:** ~115 MB

---

## Live web app

🌍 **https://app-xufuhcsz.devinapps.com**

→ "📜 Mikro-skripti" → ⭐ V15.1 PREMIUM ARSENAL lodziņš → visas pogas

---

## Atsauces

- **GitHub:** https://github.com/laurisleitaans-cyber/Pardosana
- **V15 dokumenti:** [docs/v15/](https://github.com/laurisleitaans-cyber/Pardosana/tree/devin/1777161655-v14-1-deck-automation/docs/v15)
- **Lauris Leitāns / Sharpify.io · 2026**

---

> **Mission Impossible: ✅ izpildīta.** Visi 8 artefakti FINAL.
