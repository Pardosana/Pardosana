# 🌐 ARTEFAKTS #8 · WEB APP

> **Live publiskā piekļuve V15.1 sistēmai un interaktīviem rīkiem.**

---

## Live URL

🌍 **https://app-xufuhcsz.devinapps.com**

Atver browserī → "📜 Mikro-skripti" sadaļa → ⭐ **V15.1 PREMIUM ARSENAL** zaļais lodziņš ar visām pogām.

---

## Kas ir pieejams web app

### V15.1 dokumenti (PDF lejupielādes)
- V15 Premium Book (107 lpp)
- V15 Blueprint Atlas (12 shēmas)
- V15 Whiteboard A3 šabloni (4 lpp)
- V15 Pricing Tiers (4 līmeņi)
- V15 Customer Archetypes (6 tipi)
- V15 Operator Cork (1 lpp)
- V15 Kodons (1 lpp)
- V15 Quick Reference (2 lpp)
- V15 AI Coach Prompt
- V15 Changelog

### V15.1 audio (MP3 lejupielādes, Edge Neural LV balss)
- V15 Master Audio (visa V15 narratīvs)
- V15 Operator Cork audio
- V15 Kodons audio
- V15 Quick Reference audio
- **V15 Pre-Call Ritual audio (90 sek)** ⭐ jauns

### V15.1 interaktīvi rīki ⭐
- **Knowledge Graph:** https://app-xufuhcsz.devinapps.com/v15/knowledge_graph.html
  - Klikšķini Q21.5 → redzi visu kontekstu
  - 14 mezgli vizuāli savienoti
  - Search funkcionalitāte
  - 5 vārtu mezgli izcelti ar gold ring
- **Roleplay Drill:** https://app-xufuhcsz.devinapps.com/v15/roleplay.html
  - 6 klientu arhetipi
  - 3 zvani per drill (Q3 Frame → Q22 Pitch → Q33 CARE)
  - AI feedback ar score 0-100
  - Matched/missed kritēriji
  - Bad pattern detection

---

## Snapshot (lokālais kopēta versija)

Šajā folderā (`v15_snapshot/`) ir **statisks snapshot no live web app** uz V15.1 release datumu (2026-04-26).

Lai palaistu lokāli:

```bash
cd v15_snapshot/
python3 -m http.server 8000
# Atver: http://localhost:8000
```

Tas dod tev offline piekļuvi visiem PDF/MP3/HTML rīkiem.

---

## Tehniskais stack

- **Hosting:** Devin Apps (Fly.io behind)
- **Frontend:** Pure HTML5 + SVG + vanilla JavaScript (no framework)
- **PDFs:** WeasyPrint generated, served as static files
- **Audio:** Edge Neural LV (lv-LV-NilsNeural), MP3 64kbps
- **Interactivity:** Client-side JS (no backend dependency)

---

## Drošība

- ✅ **HTTPS forced** — visi pieprasījumi šifrēti
- ✅ **Static-only** — nav lietotāju datu plūsmas, nav login formu, nav cookies
- ✅ **Public access** — nav autorizācijas (klientiem var droši dot URL)
- ⚠️ **Recordings** — Roleplay drill **NESAGLABĀ** tavus ievades (lokāls JS, nekas nesūta servera pusē)

---

## Atjaunināšana

Ja gribi atjaunināt web app pēc lokālām izmaiņām:

```bash
cd /home/ubuntu/salesengine-repo/app
# Modificē failus
# Pēc tam deploy:
# (Devin tool: deploy frontend dir=...)
```

---

## Mobilā versija

Web app ir **responsive** — strādā gan uz laptopa, gan tālrunī. Roleplay drill ir labāk uz tableta vai laptopa (rakstīšanas dēļ).
