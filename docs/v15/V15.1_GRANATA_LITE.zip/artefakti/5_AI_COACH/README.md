# 🤖 ARTEFAKTS #5 · AI COACH PAKETE

> **Dod V15 sistēmu jebkuram LLM (GPT-4, Claude, Gemini)** — viņi kļūst tava personīgā coaching un audita rīks.

---

## Kas ir iekšā

| Fails | Mērķis |
|---|---|
| `V15_AI_COACH_PROMPT.md` | Master prompt (kopējams uz GPT/Claude/Gemini) |
| `V15_AI_COACH_PROMPT.pdf` | PDF versija (drukāšanai) |

---

## Kā lietot (3 soļi)

### 1. solis · Atver LLM
- ChatGPT: https://chatgpt.com (GPT-4 vai GPT-4 Turbo)
- Claude: https://claude.ai (Sonnet 3.5 vai Opus)
- Gemini: https://gemini.google.com (Pro 1.5)

### 2. solis · Iekopē prompt
Atver `V15_AI_COACH_PROMPT.md` → kopē viss saturs → ielīmē LLM kā pirmo ziņu.

### 3. solis · Sāc trenēties

**Mode A: Klienta loma (LLM = grūts klients)**
```
Lūdzu spēlē Skeptiķi (Money MICE) tipu.
Mans Q3 Soft Frame: "Pirms cipara — vai man šis derēs..."
[Tu sāc Q3]. Reaģē kā skeptiķis.
```

**Mode B: Audits (LLM = post-call coach)**
```
Es zvanīju Vizionāram. Šeit ir mans dialogs:
[ielīmē transkriptu vai atstāstī]
Audits ar V15 sistēmu — kur es pareizi izgāju vārtus, kur palaidu garām, kā uzlabot?
```

**Mode C: Skripta pielāgošana (LLM = scripting partner)**
```
Mans klients ir IT konsultants Latvijā, vidējais čeks €5k, 3 klienti mēnesī. 
Pielāgo Q11 GAP atklāšanas skriptu šim profilam — konkrētus jautājumus.
```

---

## Ko AI Coach var darīt

✓ **Spēlēt 6 klientu arhetipus** (Skeptiķis / Vizionārs / Pragmatiķis / Lepnais / Analītiķis / Pirmsreizējais)
✓ **Auditu pēc zvana** — kurā Q-mezglā iesprūdi, kurš vārts palaidu garām
✓ **Pielāgot frāzes** — tavam tirgum, klienta profilam, MICE tipam
✓ **Pārbaudīt CARE atbildes** — vai tava reakcija uz iebildumu pareiza
✓ **Skriptu paplašināšana** — ja prasāt "kāda nākošā frāze pēc Q21.5"
✓ **Kalibrēt 5 vārtus** — pārbaudīt, vai izgājis visus

---

## Ko AI Coach NEVAR darīt

✗ **NEVAR aizvietot reālu zvanu** — sistēma der treniņam, ne live klientiem
✗ **NEVAR garantēt 100% precīzas atbildes** — LLM var halucinēt; pārbaudi pret Premium Book
✗ **NEVAR pārvaldīt tavu CRM** — tas ir cits rīks
✗ **NEVAR ierakstīt audio** — Fathom vai cits tools to dara

---

## Drošības svarīgs

> **NEKAD nedāvini īstu klientu PII (vārds, telefons, email)** AI coach prompt. Lieto pseudonīmus.

> **NEKAD nepublicē** klientu zvanu transkriptus AI bez klienta atļaujas.

> AI Coach ir **PRIVĀTS treniņa partneris**, ne klientu datu apstrāde.

---

## 3 testa scenāriji (pārbaudi sava AI Coach kvalitāti)

### Tests #1: "Cik maksā?"
Iemet AI: *"Klients sāk ar 'Cik maksā?' Spēlē viņu. Es atbildu ar Q3 Soft Frame."*

**Sagaidāmā AI reakcija:** turpina pretestību, prasa konkrētu ciparu, **netic** uzreiz.

Ja AI viegli piekrīt — tava prompt nav iekraujamies. Atvieglo to.

### Tests #2: Hope Break audits
Iemet AI: *"Mans Q21.5: 'Vai tu pasīvi gaidi vai aktīvi vadi?' Klients atbildēja: 'Es darītu, ja būtu laiks.' Vai es varu pāriet uz Q22?"*

**Sagaidāmā AI reakcija:** *"Nē — 'ja būtu laiks' ir izvairīšanās. Klients NAV atzinis pasīvi. Atkārto Hope Break ar 3. kāpni: '2 nedēļās 5 klientus — kā konkrēti?'"*

### Tests #3: MICE pārklasifikācija
Iemet AI: *"Klients teica: 'Pirms 5 gadiem bizness bija labāks.' Kāds MICE?"*

**Sagaidāmā AI reakcija:** *"Ego-driven (Lepnais arhetips). Q22+Q26 valoda fokusē uz **atgriešanos tronī**, ne uz peļņu. Konkrēti: 'Tu agrāk bija #1. Šī sistēma palīdz atgriezties tronī ar drošāku pamatu.'"*

---

> **Padoms:** Ja AI Coach atbildes ir **vispārīgas** (piem., "Tas ir labi, turpini!"), tas nozīmē, ka tu vai nu (a) iekopēja prompt nepilnīgi, (b) lieto vājāku LLM (GPT-3.5, ne GPT-4), vai (c) AI nepieguves māja kontekstā.
>
> **Risinājums:** Sāc no nulles ar pilnu prompt, lieto GPT-4 vai Claude Sonnet 3.5+, un dod KONKRĒTUS scenārijus, ne vispārīgus.
