# 🛡️ SALESENGINE V16 · BATTLE-READY EDITION

> **V14.1 kanons + V15 bagātība + V16 disciplīna = battle-ready operatoram.**

---

## Atbilde uz outside audit (Lawrence)

> *"V14.1 = pareizais kanons (tīrāks). V15 = stiprāks kā kopējā premium grāmata, BET ar pārkarsēšanas risku."*

V16 nav jauna sistēma. **V16 ir disciplīnas slānis**, kas pasaka:
- ✓ kas ir **CORE** (V14.1, sacrosanct)
- ✓ kas ir **BATTLE PACK** (zvanā nes tikai šo)
- ✓ kas ir **STUDY PACK** (mācies aiz darba laika)
- ✓ kas ir **LV-NATIVE validēts** (Lauris dzīvajos zvanos)
- ✓ kas ir **EN-DERIVED** (no IG/FB, vēl jāpārbauda)

---

## Mape

```
v16-build/
├── README.md                              ← ŠEIT
│
├── battle_pack/                           ⚔️ ZVANĀ NES TIKAI ŠO
│   ├── V16_WAR_MAP_A4.pdf                 (1 lpp, viss)
│   ├── V16_PRECALL_RITUAL.mp3             (90 sek audio)
│   └── V16_4_A3_WHITEBOARD.pdf            (4 A3 šabloni klientiem)
│
└── study_pack/                            🎓 MĀCĪBĀM AIZ DARBA LAIKA
    ├── V16_PREMIUM_BOOK.pdf               (V16 master dokuments)
    ├── V16_FAST_START_7DAY.pdf            (Day 0 → Day 7 ceļvedis)
    ├── V16_ANTI_OVERLOAD.pdf              (7 aizliegumi · 1 zelta likums)
    ├── V16_LAWRENCE_AUDIT.pdf             (V14.1 vs V15 outside view)
    ├── V14_1_CORE_LV_MASTER_SCRIPT.md     (V14.1 kanons, sacrosanct)
    ├── V15_PREMIUM_BOOK_REFERENCE.pdf     (V15 pilnais Premium Book)
    ├── V15_BLUEPRINT_ATLAS.pdf            (12 LV blueprint shēmas)
    ├── V15_CUSTOMER_ARCHETYPES.pdf        (6 klientu tipi)
    └── V15_PRICING_TIERS.pdf              (4 cenu līmeņi)
```

---

## V16 ZELTA LIKUMS

> ⚠️ **Vienā zvanā maksimums 1 ARSENAL mezgls. Pārējie ir nākamajiem zvaniem.**

V15 deva 11 jaunus mezglus. V16 marķē **TOP 4 ar 🟢 zaļu zvaigzni** (LV-native validēti):

| # | Mezgls | LV-native | Disciplīna |
|---|---|---|---|
| 🟢 1 | Tonalitātes 5 balsis | ✓ | Drillas 1 ned. pirms zvana |
| 🟢 2 | Mikro-jā cilpa | ✓ | Maksimums 3 mikro-jā per zvans |
| 🟢 3 | Klusais slēgums 8-15s | ✓ | NEPIRMAIS pārtrauc |
| 🟢 4 | Hope Fog 3 kāpnes | ✓ | Q21.5 LOAD-BEARING |

Pārējie 7 (Ghosting, Takeaway, Spoguļošana, CEO objection, Lojalitātes cilpa, Voss Nē, Manipulācija vs Inspirācija) — paliek STUDY PACK mājā. Lieto **tikai pēc 90 dienām un 50+ live zvaniem**.

---

## V16 = V15 + 5 jauni disciplīnas slāņi

| # | V16 jauns slānis | Kāpēc |
|---|---|---|
| 1 | **BATTLE PACK ⟷ STUDY PACK split** | Operators zvanā nes 1 lpp, ne 107 lpp grāmatu |
| 2 | **Pareto Top 4 ARSENAL** | Disciplinēti mācies 4 dziļi, nevis 11 virspusēji |
| 3 | **LV-native vs EN-derived markējums** | Godīga validācija (90% V15 korpusa bija EN) |
| 4 | **Anti-Overload protokols** | 7 aizliegumi pret pārkarsēšanu zvanā |
| 5 | **Fast-Start 7 dienu programma** | No 30 dienām → 7 dienām līdz Līmenis 1 |

---

## Quick Start (3 min)

### Tu esi pieredzējis V15 lietotājs
1. Atver `study_pack/V16_LAWRENCE_AUDIT.pdf` (5 min)
2. Atver `battle_pack/V16_WAR_MAP_A4.pdf` un drukā uz A4
3. Atver `study_pack/V16_ANTI_OVERLOAD.pdf` (10 min)
4. **Beigas. Tu esi V16 pakāpē.**

### Tu esi jauns operators
1. Atver `study_pack/V16_FAST_START_7DAY.pdf`
2. Sāc Day 0 (15 min)
3. Seko 7 dienu programmai
4. Pēc 7 dienām esi V16 Līmenis 1

---

## V16 Līmeņi · ceļvedis

| Līmenis | Diena | Arsenal mezgli zvanā |
|---|---|---|
| L1 | Day 7 | 1 (Tonalitāte) |
| L2 | Day 30 | 1 (jebkurš no TOP 4) |
| L3 | Day 90 | 2 (no TOP 4 ar 50+ live zvaniem) |
| L4 | Day 180+ | 3 (kombinācijas) |
| L5 | Day 365+ | Visi 11 (situatīvi) |

---

## V16 INTEGRITATĒ

✅ V14.1 LV_MASTER_SCRIPT.md (2128 līnijas) ir BYTE-FOR-BYTE neaizskarta
✅ V15 saturs ir saglabāts `study_pack/` mapē
✅ V16 ir DISCIPLINĀS slānis virsū, ne aizvietojums

---

## Lieto

🌐 **Live URL:** https://app-xufuhcsz.devinapps.com (V15.1 pieejams; V16 pievienosies pēc deploy)

📁 **GitHub:** https://github.com/laurisleitaans-cyber/Pardosana

📦 **Mega-zip:** `V16.0_GRANATA.zip`

---

> **V16 filozofija:** *Tu mācies VIENU lietu nedēļā un to dari līdz tā kļūst muskuļu atmiņā. Pēc tam pievieno nākošo. V15 gribēja, lai tu zinātu visu. V16 grib, lai tu RĪKOJIES ar pareizo lietu pareizajā brīdī.*

— Lauris Leitāns / Sharpify.io · 2026
